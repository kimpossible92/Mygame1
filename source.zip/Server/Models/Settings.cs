﻿namespace Server.Models;

public class Settings
{
    public string BearerKey { get; set; }
}