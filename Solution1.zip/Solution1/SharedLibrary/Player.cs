﻿namespace SharedLibrary;

public class Player
{
    public int Id;
    public int Level;
    public float Health;
}