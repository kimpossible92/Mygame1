﻿using Microsoft.AspNetCore.Mvc;

namespace Server.Controllers;
[ApiController]
[Route("[controller]")]
public class AuthenticationController : ControllerBase
{
    [HttpPost("register")]
    public void Register()
    {
        
    }

    [HttpPost("login")]
    public void Login(){
        
    }
}