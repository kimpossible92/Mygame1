﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using Server.Models;
using SharedLibrary;
namespace Server.Services;

public class AuthenticationService : IAuthenticationService
{
    private readonly Settings _settings;
    private readonly GameDbContext _context;
    public AuthenticationService(Settings settings,GameDbContext context)
    {
    _settings =settings;
    _context = context;
    }
    public (bool success,string content) Register(string username,string password){
    
    }
    public (bool success,string token) Login(string username,string password){
        
    }
    private ClaimsIdentity AssemblyClaimsIdentity(User user)
    {
    
    }
    private string GenerateJwtToken(ClaimsIdentity subject)
    {
    
    }
}
public interface IAuthenticationService
{
public (bool success,string content) Register(string username,string password);
public (bool success,string token) Login(string username,string password){
}
