﻿using Microsoft.AspNetCore.Mvc;
using SharedLibrary;
using Server.Services;
namespace Server.Controllers;
[ApiController]
[Route("[controller]")]
public class PlayerController : Controller
{
    private readonly IPlayerService _playerService;
    private readonly GameDBContext _context;
    public PlayerController(IPlayerService playerService,GameDBContext context)
    {
        _playerService = playerService;
        _context = context;

        var user = new User()
        {
            Username = "tar",
            PasswordHash = "password69",
            Salt = "hjsakhdkjsa"
        };
        _context.Add(user);
        _context.SaveChanges();
    }
    [HttpGet("{id}")]
    public Player Get([FromRoute] int id)
    {
        var player = new Player(){Id=id};
        _playerService.Do();
        return player;
    }
    [HttpPost]
    public Player Post(Player player)
    {
        Console.WriteLine("Player has been added to the DataBase");
        return player;
    }
}